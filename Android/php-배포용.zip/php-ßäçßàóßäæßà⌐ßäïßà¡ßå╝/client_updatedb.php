<?php
//클라이언트가 state를 변경하는 php
    //0. 설정
    error_reporting(E_ALL);
    ini_set('display_errors',1);
    $mysql_hostname = 'localhost';
    $mysql_username = '';
    $mysql_password = '';
    $mysql_database = '';
    $mysql_port = '';
    $mysql_charset = 'utf8';

    //1. DB 연결
    $conn = new mysqli($mysql_hostname, $mysql_username, $mysql_password, $mysql_database, $mysql_port);

    if($conn->connect_errno){
    	echo '[연결실패] : '.$conn->connect_error.'<br>';
      exit();
    } else{
      echo '[success]';
    }
    //2. 문자셋 지정
    if(! $conn->set_charset($mysql_charset))// (php >= 5.0.5)
    {
    	echo '[문자열변경실패] : '.$conn->connect_error;
    }

    //3. POST 값을 읽어온다.
    $id=isset($_POST['id']) ? $_POST['id'] : '';
    $pwd=isset($_POST['pwd']) ? $_POST['pwd'] : '';
    $state=isset($_POST['state']) ? $_POST['state'] : '';

    // 강의실 정보에 따라 디비 테이블을 변경함.
    $table = substr($pwd, 0, 1);
    if($table == "6"){
      $table = "IJM06";
    }

    // 값이 있는지 확인, 있으면 update 없으면 insert
    if ($id !="" and $pwd !="" and $state !="" ){
      // 값이 있으면 update 없으면 초기화 주기적으로 접속하는 부분
      $sql="update $table SET state = $state, conn_cnt = conn_cnt + 1 WHERE mac_address = '$id'";
      $result=mysqli_query($conn,$sql);

      if(!$result){
         echo "SQL문 처리중 에러 발생 : ";
         echo mysqli_error($conn);
      }else{
        echo "existing";
      }
    }

    //4. 종료
    $conn->close();
?>
