<?php
// 디비를 검색하여 해당 맥어드레스가 처음접속인지 아닌지를 확인하는 php
    //0. 설정
    error_reporting(E_ALL);
    ini_set('display_errors',1);
    $mysql_hostname = 'localhost';
    $mysql_username = '';
    $mysql_password = '';
    $mysql_database = '';
    $mysql_port = '';
    $mysql_charset = 'utf8';

    //1. DB 연결
    $conn = new mysqli($mysql_hostname, $mysql_username, $mysql_password, $mysql_database, $mysql_port);

    if($conn->connect_errno){
    	echo '[연결실패] : '.$conn->connect_error.'<br>';
      exit();
    }
    //2. 문자셋 지정
    if(! $conn->set_charset($mysql_charset))// (php >= 5.0.5)
    {
    	echo '[문자열변경실패] : '.$conn->connect_error;
    }

    //3. POST 값을 읽어온다.
    $id=isset($_POST['id']) ? $_POST['id'] : '';
    $pwd=isset($_POST['pwd']) ? $_POST['pwd'] : '';
    $state=isset($_POST['state']) ? $_POST['state'] : '';


// 수정사항 전체 테이블을 검색하고 값이 있는지를 확인해야해
    // 값이 있는지 확인
    if ($id !="" and $pwd !="" and $state !="" ){
      //$sql="select mac_address FROM IJM06 WHERE mac_address = '$id'";
      //$sql="select IF(strcmp(mac_address,'$id'),0,1) 'mac_chk' FROM ADDY  WHERE mac_address = '$id'";
      $sql="select * FROM ADDY  WHERE mac_address = '$id'";
      $result = mysqli_query($conn,$sql);
      if($result)
      {
        $row = mysqli_fetch_array($result);
        if($row[1] == "")
        {
          //쿼리문이 잘 돌았다., 값은 없다. 초기화
          echo "init";
        }
        else
        {
          // 값이 있으면 update 없으면 초기화
          echo $row[2];

          //echo "existing";   // 0이면 비밀번호 불일치, 1이면 일치
        }
      }
    }

    //4. 종료
    $conn->close();
?>
