<?php
//안드로이드에서 현재 로그인 중인 컴퓨터를 확인하는 php
  //0. 설정
  error_reporting(E_ALL);
  ini_set('display_errors',1);
  $mysql_hostname = 'localhost';
  $mysql_username = '';
  $mysql_password = '';
  $mysql_database = '';
  $mysql_port = '';
  $mysql_charset = 'utf8';

  //1. DB 연결
  $conn = new mysqli($mysql_hostname, $mysql_username, $mysql_password, $mysql_database, $mysql_port);

  if($conn->connect_errno){
    echo '[연결실패]';
    exit();
  }
  //2. 문자셋 지정
  if(! $conn->set_charset($mysql_charset))// (php >= 5.0.5)
  {
    echo '[문자열변경실패]';
  }

  //3. POST 값을 읽어온다.
  $table=isset($_POST['table']) ? $_POST['table'] : '';

  $sql1 = "select mac_address from $table where state > 0";
  $sql2 = "select mac_address from $table";

  $result1 = mysqli_query($conn,$sql1);
  $result2 = mysqli_query($conn,$sql2);
  // result of sql query

  if($result1)
  {
    //쿼리문이 몇개 추출되는지 알수 있다.
    $i =  mysqli_num_rows($result1);
  }else{
    echo "SQL문 처리중 에러 발생 : ";
    echo mysqli_error($conn);
  }

  if($result2)
  {
    $total =  mysqli_num_rows($result2);
  }else{
    echo "SQL문 처리중 에러 발생 : ";
    echo mysqli_error($conn);
  }

  echo $i. ' / '.$total;
?>
