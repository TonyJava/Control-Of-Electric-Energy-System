<?php
//안드로이드에서 현재 로그인한 컴퓨터를 끄기위한 php
  //0. 설정
  error_reporting(E_ALL);
  ini_set('display_errors',1);
  $mysql_hostname = 'localhost';
  $mysql_username = '';
  $mysql_password = '';
  $mysql_database = '';
  $mysql_port = '';
  $mysql_charset = 'utf8';

  //1. DB 연결
  $conn = new mysqli($mysql_hostname, $mysql_username, $mysql_password, $mysql_database, $mysql_port);

  if($conn->connect_errno){
    echo '[연결실패] : '.$conn->connect_error.'<br>';
    exit();
  }
  //2. 문자셋 지정
  if(! $conn->set_charset($mysql_charset))// (php >= 5.0.5)
  {
    echo '[문자열변경실패] : '.$conn->connect_error;
  }

  //3. POST 값을 읽어온다.
  $table=isset($_POST['table']) ? $_POST['table'] : '';

  $sql = "update $table SET init = '0'";
  $result = mysqli_query($conn,$sql);

  if(!$result){
     echo "SQL문 처리중 에러 발생 : ";
     echo mysqli_error($conn);
  }
?>
